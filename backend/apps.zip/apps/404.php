<!DOCTYPE html>
<html>
<head>
    <title>404 Not Found</title>
</head>
<body>
<h1>404</h1>
<p>OOPS! Something went wrong here</p>
</body>
</html>
